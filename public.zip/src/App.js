import logo from './logo.svg';
import './App.css';
import Cadastro from './Cadastro';
import ChatRoom from './ChatRoom';

function App() {
  return (
    <div className="App">
      <header className="App-header">
     <ChatRoom></ChatRoom>
      </header>
    </div>
  );
}

export default App;
