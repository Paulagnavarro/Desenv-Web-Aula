import { useState, useEffect } from 'react';

export default function ChatRoom() {
    const [listPosts, setlistPosts] = useState('');

    const options ={
        method: 'GET'
    };

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/posts',options)
            .then(response => response.json())
            .then(data => setlistPosts(data));
    }, []);
    return (
        <div>
            <p>Dados: {listPosts.results.map(post => <div> {post.title}</div>)}</p>
        </div>
    );
} 

